from ultralytics import YOLO

def main():
    model = YOLO("yolov8n.pt")

    model.train(
        data="data1.yaml",
        epochs=40,
        imgsz=640,
        batch=16,
        device=0,
        name="肾结石_yolov8",
        project=r"E:\anaconda1\deep-learning\0yolo肾结石检测/runs"
    )

if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support()
    main()
