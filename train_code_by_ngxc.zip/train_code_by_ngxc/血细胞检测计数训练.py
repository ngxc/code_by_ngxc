from ultralytics import YOLO

def main():
    model = YOLO("yolov8n.pt")

    model.train(
        data="data1.yaml",
        epochs=100,
        imgsz=640,
        batch=16,
        device=0,
        name="blood_cells_yolov8",
        project=r"E:\anaconda1\deep-learning\0yolo血细胞计数/runs"
    )

if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support()
    main()
