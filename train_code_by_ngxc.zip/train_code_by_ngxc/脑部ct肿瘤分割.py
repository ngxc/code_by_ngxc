import os
from PIL import Image
import torch
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as T
from transformers import SegformerForSemanticSegmentation, SegformerImageProcessor
import numpy as np
import torch.nn.functional as F
from tqdm import tqdm
import matplotlib.pyplot as plt
os.environ['HTTP_PROXY'] = 'http://127.0.0.1:7890'
os.environ['HTTPS_PROXY'] = 'http://127.0.0.1:7890'
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class SegDataset(Dataset):
    def __init__(self, img_dir, mask_dir, image_processor, size=(512, 512)):
        self.img_dir = img_dir
        self.mask_dir = mask_dir
        self.size = size
        self.processor = image_processor
        self.images = sorted(os.listdir(img_dir))

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        img_name = self.images[idx]
        img_path = os.path.join(self.img_dir, img_name)
        mask_path = os.path.join(self.mask_dir, img_name.replace(".jpg", "_mask.png").replace(".png", "_mask.png"))

        image = Image.open(img_path).convert("RGB").resize(self.size)
        mask = Image.open(mask_path).convert("L").resize(self.size)

        inputs = self.processor(images=image, return_tensors="pt")
        pixel_values = inputs.pixel_values.squeeze()
        label = torch.tensor(np.array(mask) > 0).long()
        return pixel_values, label, np.array(image), np.array(mask), img_name

def save_val_visualization(epoch, images, preds, masks, img_names, save_dir="val_visualizations", max_samples=10):
    os.makedirs(f"{save_dir}/epoch_{epoch}", exist_ok=True)
    for i in range(min(max_samples, len(images))):
        img = images[i]
        pred_mask = preds[i].cpu().numpy()
        true_mask = masks[i].cpu().numpy()


        pred_mask_resized = np.array(
            Image.fromarray(pred_mask.astype(np.uint8)*255).resize((img.shape[1], img.shape[0]), resample=Image.NEAREST)
        )
        pred_mask_resized = (pred_mask_resized > 127).astype(np.uint8)


        if true_mask.shape != img.shape[:2]:
            true_mask = np.array(
                Image.fromarray(true_mask.astype(np.uint8)*255).resize((img.shape[1], img.shape[0]), resample=Image.NEAREST)
            )
            true_mask = (true_mask > 127).astype(np.uint8)

        def mask_to_rgb(mask):
            rgb = np.zeros((mask.shape[0], mask.shape[1], 3), dtype=np.uint8)
            rgb[mask == 1] = [255, 0, 0]
            return rgb

        pred_rgb = mask_to_rgb(pred_mask_resized)
        true_rgb = mask_to_rgb(true_mask)

        overlay_pred = (img * 0.5 + pred_rgb * 0.5).astype(np.uint8)
        overlay_true = (img * 0.5 + true_rgb * 0.5).astype(np.uint8)

        concat_img = np.concatenate([img, overlay_pred, overlay_true], axis=1)

        save_path = os.path.join(save_dir, f"epoch_{epoch}", f"{img_names[i]}")
        if not save_path.endswith(".png"):
            save_path = os.path.splitext(save_path)[0] + ".png"
        Image.fromarray(concat_img).save(save_path)


processor = SegformerImageProcessor(do_resize=False, do_normalize=True)
model = SegformerForSemanticSegmentation.from_pretrained(
    "nvidia/segformer-b0-finetuned-ade-512-512",
    num_labels=2,
    ignore_mismatched_sizes=True,
).to(device)

train_set = SegDataset("dataset_split/train/images", "dataset_split/train/masks", processor)
val_set = SegDataset("dataset_split/val/images", "dataset_split/val/masks", processor)
train_loader = DataLoader(train_set, batch_size=4, shuffle=True)
val_loader = DataLoader(val_set, batch_size=4)

optimizer = torch.optim.Adam(model.parameters(), lr=2e-4)

for epoch in range(1, 6):
    model.train()
    total_loss = 0
    for imgs, masks, _, _, _ in tqdm(train_loader, desc=f"Epoch {epoch}"):
        imgs, masks = imgs.to(device), masks.to(device)
        outputs = model(pixel_values=imgs, labels=masks)
        loss = outputs.loss
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        total_loss += loss.item()

    print(f" Epoch {epoch} Loss: {total_loss / len(train_loader):.4f}")

    model.eval()
    iou_total = 0
    val_images, val_preds, val_masks, val_img_names = [], [], [], []
    with torch.no_grad():
        for imgs, masks, orig_imgs, orig_masks, img_names in val_loader:
            imgs, masks = imgs.to(device), masks.to(device)
            logits = model(pixel_values=imgs).logits
            preds = logits.argmax(dim=1)

            masks_resized = F.interpolate(masks.unsqueeze(1).float(), size=preds.shape[1:], mode='nearest').squeeze(1).long()

            intersection = ((preds == 1) & (masks_resized == 1)).sum().float()
            union = ((preds == 1) | (masks_resized == 1)).sum().float()
            iou = (intersection + 1e-6) / (union + 1e-6)
            iou_total += iou.item()

            # 收集前4张图片数据用于保存
            if len(val_images) < 10:
                val_images.extend(orig_imgs.numpy())
                val_preds.extend(preds.cpu())
                val_masks.extend(masks_resized.cpu())
                val_img_names.extend(img_names)

    print(f"Val IoU: {iou_total / len(val_loader):.4f}")

    # 保存验证集可视化
    save_val_visualization(epoch, val_images, val_preds, val_masks, val_img_names)

torch.save(model.state_dict(), "segformer_brain_tumor.pth")
print(" val_visualizations/ 目录")
