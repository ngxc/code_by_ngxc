import os
import random
from PIL import Image
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as T
import torchvision.transforms.functional as TF
import segmentation_models_pytorch as smp


class CrackSegDataset(Dataset):
    def __init__(self, img_mask_pairs, transform_img=None, transform_mask=None):
        self.pairs = img_mask_pairs
        self.transform_img = transform_img
        self.transform_mask = transform_mask

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, idx):
        img_path, mask_path = self.pairs[idx]
        image = Image.open(img_path).convert("RGB")
        mask = Image.open(mask_path).convert("L")

        if self.transform_img:
            image = self.transform_img(image)
        if self.transform_mask:
            mask = self.transform_mask(mask)

        mask = (mask > 0.5).float()
        return image, mask


def split_dataset(all_dir, val_count=5, seed=42):
    all_files = os.listdir(all_dir)
    image_files = sorted([f for f in all_files if f.endswith(".jpg") and "_1stHO" not in f and "_2ndHO" not in f])
    base_names = [os.path.splitext(f)[0] for f in image_files]

    random.seed(seed)
    val_bases = set(random.sample(base_names, val_count))
    train_pairs, val_pairs = [], []

    for base in base_names:
        img_path = os.path.join(all_dir, base + ".jpg")
        for suffix in ["_1stHO.png", "_2ndHO.png"]:
            mask_path = os.path.join(all_dir, base + suffix)
            if os.path.exists(mask_path):
                pair = (img_path, mask_path)
                if base in val_bases:
                    val_pairs.append(pair)
                else:
                    train_pairs.append(pair)

    print(f"Train samples: {len(train_pairs)}, Val samples: {len(val_pairs)}")
    return train_pairs, val_pairs


def iou_pytorch(outputs, labels, threshold=0.5):
    outputs = (outputs > threshold).float()
    labels = (labels > 0.5).float()
    intersection = (outputs * labels).sum(dim=(1, 2, 3))
    union = (outputs + labels - outputs * labels).sum(dim=(1, 2, 3))
    iou = (intersection + 1e-6) / (union + 1e-6)
    return iou.mean().item()


def dice_coef(outputs, labels, threshold=0.5):
    outputs = (outputs > threshold).float()
    labels = (labels > 0.5).float()
    intersection = (outputs * labels).sum(dim=(1, 2, 3))
    dice = (2 * intersection + 1e-6) / (outputs.sum(dim=(1, 2, 3)) + labels.sum(dim=(1, 2, 3)) + 1e-6)
    return dice.mean().item()


def save_visualization(img_tensor, pred_tensor, mask_tensor, save_path, idx):
    os.makedirs(save_path, exist_ok=True)
    img = TF.to_pil_image(img_tensor.cpu())
    pred = pred_tensor.sigmoid().cpu()
    pred = (pred > 0.5).float()
    pred_img = TF.to_pil_image(pred.squeeze(0))
    mask_img = TF.to_pil_image(mask_tensor.cpu().squeeze(0))

    total_width = img.width + pred_img.width + mask_img.width
    new_img = Image.new('RGB', (total_width, img.height))
    new_img.paste(img, (0, 0))
    new_img.paste(pred_img.convert('RGB'), (img.width, 0))
    new_img.paste(mask_img.convert('RGB'), (img.width + pred_img.width, 0))

    new_img.save(os.path.join(save_path, f"val_epoch_img_{idx}.png"))

def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    all_dir = r"D:\anaconda\deep-learning\0眼底血管分割\CHASEDB1"

    # 划分数据集
    train_pairs, val_pairs = split_dataset(all_dir, val_count=5)

    # 数据增强
    transform_img = T.Compose([T.Resize((640, 640)), T.ToTensor()])
    transform_mask = T.Compose([T.Resize((640, 640)), T.ToTensor()])

    train_dataset = CrackSegDataset(train_pairs, transform_img, transform_mask)
    val_dataset = CrackSegDataset(val_pairs, transform_img, transform_mask)

    train_loader = DataLoader(train_dataset, batch_size=4, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=4, shuffle=False)


    model = smp.Unet(
        encoder_name="resnet18",
        encoder_weights="imagenet",
        in_channels=3,
        classes=1,
    ).to(device)

    criterion = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)


    epochs = 20
    for epoch in range(epochs):
        model.train()
        train_loss = 0
        for imgs, masks in train_loader:
            imgs, masks = imgs.to(device), masks.to(device)
            preds = model(imgs)
            loss = criterion(preds, masks)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            train_loss += loss.item()

        print(f"Epoch {epoch+1}/{epochs} Train Loss: {train_loss / len(train_loader):.4f}")

        model.eval()
        val_loss, ious, dices = 0, [], []
        save_dir = f"val_visualizations/epoch_{epoch+1}"
        with torch.no_grad():
            for batch_idx, (imgs, masks) in enumerate(val_loader):
                imgs, masks = imgs.to(device), masks.to(device)
                preds = model(imgs)
                loss = criterion(preds, masks)
                val_loss += loss.item()
                ious.append(iou_pytorch(preds, masks))
                dices.append(dice_coef(preds, masks))

                # 保存前两 batch 的可视化
                if batch_idx < 2:
                    for i in range(min(2, imgs.size(0))):
                        save_visualization(imgs[i], preds[i], masks[i], save_dir, batch_idx * 2 + i)

        avg_iou = sum(ious) / len(ious)
        avg_dice = sum(dices) / len(dices)
        print(f"Epoch {epoch+1}/{epochs} Val Loss: {val_loss / len(val_loader):.4f} IoU: {avg_iou:.4f} Dice: {avg_dice:.4f}")
        print(f"Validation visualizations saved to: {save_dir}")


    os.makedirs("checkpoints", exist_ok=True)
    torch.save(model.state_dict(), "checkpoints/unet_crack_seg.pth")
    print("已保存至checkpoints/unet_crack_seg.pth")

if __name__ == "__main__":
    main()
