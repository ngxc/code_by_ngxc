import json
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, Subset, random_split
from transformers import BertTokenizer, BertModel
from tqdm import tqdm
import os


os.environ['HTTP_PROXY'] = 'http://127.0.0.1:7890'
os.environ['HTTPS_PROXY'] = 'http://127.0.0.1:7890'


label_map = {
    "无糖尿病": 0,
    "前期糖尿病": 1,
    "糖尿病": 2
}


class DiabetesJsonlDataset(Dataset):
    def __init__(self, jsonl_path, tokenizer, max_length=128):
        self.samples = []
        self.tokenizer = tokenizer
        self.max_length = max_length
        with open(jsonl_path, 'r', encoding='utf-8') as f:
            for line in f:
                item = json.loads(line)
                text = item['instruction'] + " " + item['input']
                label_text = item['output'].strip()
                if label_text not in label_map:
                    continue
                label = label_map[label_text]
                self.samples.append((text, label))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        text, label = self.samples[idx]
        encoding = self.tokenizer(
            text,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        item = {key: val.squeeze(0) for key, val in encoding.items()}
        item['labels'] = torch.tensor(label, dtype=torch.long)
        return item


class BertForDiabetesClassification(nn.Module):
    def __init__(self, pretrained_model_name='hfl/chinese-roberta-wwm-ext', num_classes=3):
        super().__init__()
        self.bert = BertModel.from_pretrained(pretrained_model_name)
        self.classifier = nn.Linear(self.bert.config.hidden_size, num_classes)

    def forward(self, input_ids, attention_mask):
        outputs = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        pooled_output = outputs.pooler_output
        logits = self.classifier(pooled_output)
        return logits


def train(jsonl_path, epochs=5, batch_size=32, lr=2e-5):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    tokenizer = BertTokenizer.from_pretrained('hfl/chinese-roberta-wwm-ext')
    full_dataset = DiabetesJsonlDataset(jsonl_path, tokenizer)


    total_indices = torch.randperm(len(full_dataset))
    selected_indices = total_indices[:15000]
    remaining_indices = total_indices[15000:]

    trainval_dataset = Subset(full_dataset, selected_indices)
    test_dataset = Subset(full_dataset, remaining_indices)

    train_dataset, val_dataset = random_split(trainval_dataset, [14700, 300])

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size)
    test_loader = DataLoader(test_dataset, batch_size=batch_size)

    model = BertForDiabetesClassification().to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr)
    criterion = nn.CrossEntropyLoss()

    for epoch in range(epochs):
        model.train()
        total_loss = 0
        print(f"\nEpoch {epoch + 1} Training:")
        for batch in tqdm(train_loader):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels = batch['labels'].to(device)

            optimizer.zero_grad()
            logits = model(input_ids=input_ids, attention_mask=attention_mask)
            loss = criterion(logits, labels)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()

        avg_loss = total_loss / len(train_loader)
        print(f"Epoch {epoch + 1} training loss: {avg_loss:.4f}")

        model.eval()
        correct = 0
        total = 0
        print(f"Epoch {epoch + 1} Validation:")
        with torch.no_grad():
            for batch in tqdm(val_loader):
                input_ids = batch['input_ids'].to(device)
                attention_mask = batch['attention_mask'].to(device)
                labels = batch['labels'].to(device)
                logits = model(input_ids=input_ids, attention_mask=attention_mask)
                preds = torch.argmax(logits, dim=1)
                correct += (preds == labels).sum().item()
                total += labels.size(0)
        acc = correct / total
        print(f"Epoch {epoch + 1} validation accuracy: {acc:.4f}")


    if len(test_dataset) > 0:
        print("\nFinal Evaluation on Remaining Test Set:")
        model.eval()
        correct = 0
        total = 0
        with torch.no_grad():
            for batch in tqdm(test_loader):
                input_ids = batch['input_ids'].to(device)
                attention_mask = batch['attention_mask'].to(device)
                labels = batch['labels'].to(device)
                logits = model(input_ids=input_ids, attention_mask=attention_mask)
                preds = torch.argmax(logits, dim=1)
                correct += (preds == labels).sum().item()
                total += labels.size(0)
        acc = correct / total
        print(f"\nFinal test accuracy on remaining {total} samples: {acc:.4f}")
    else:
        print("\nNo remaining dataset for final test evaluation.")


if __name__ == "__main__":
    jsonl_path = "diabetes_training.jsonl"
    print("111开始")
    train(jsonl_path)
