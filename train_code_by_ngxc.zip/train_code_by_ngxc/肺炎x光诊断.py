import os
import torch
import torch.nn as nn
from torchvision import datasets, transforms, models
from torch.utils.data import DataLoader
from torch.optim import Adam
from sklearn.metrics import classification_report
from tqdm import tqdm
from collections import Counter


data_dir = r'D:\anaconda\deep-learning\0肺炎x光\archive (2)\chest_xray'
batch_size = 200
num_epochs = 6
lr = 5e-4
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


train_transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(15),
    transforms.ColorJitter(brightness=0.2, contrast=0.2),
    transforms.Grayscale(num_output_channels=1),
    transforms.ToTensor(),
    transforms.Normalize([0.5], [0.5]),
])

test_transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.Grayscale(num_output_channels=1),
    transforms.ToTensor(),
    transforms.Normalize([0.5], [0.5]),
])

train_set = datasets.ImageFolder(os.path.join(data_dir, 'train'), transform=train_transform)
val_set   = datasets.ImageFolder(os.path.join(data_dir, 'val'), transform=test_transform)
test_set  = datasets.ImageFolder(os.path.join(data_dir, 'test'), transform=test_transform)

train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True)
val_loader   = DataLoader(val_set, batch_size=batch_size)
test_loader  = DataLoader(test_set, batch_size=batch_size)


class PneumoniaResNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.backbone = models.resnet18(weights=models.ResNet18_Weights.DEFAULT)
        self.backbone.conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
        self.backbone.fc = nn.Identity()

        self.classifier = nn.Sequential(
            nn.Linear(512, 128),
            nn.ReLU(),
            nn.BatchNorm1d(128),
            nn.Dropout(0.5),
            nn.Linear(128, 1)
        )

    def forward(self, x):
        features = self.backbone(x)
        out = self.classifier(features)
        return out


model = PneumoniaResNet().to(device)


criterion = nn.BCEWithLogitsLoss()

optimizer = Adam(model.parameters(), lr=lr)


for epoch in range(num_epochs):
    model.train()
    total_loss = 0
    correct = 0
    loop = tqdm(train_loader, desc=f"Epoch [{epoch+1}/{num_epochs}] Training", ncols=100)
    for images, labels in loop:
        images = images.to(device)
        labels = labels.to(device).float().unsqueeze(1)

        outputs = model(images)
        loss = criterion(outputs, labels)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

        preds = (torch.sigmoid(outputs) > 0.5).long()
        correct += (preds == labels.long()).sum().item()

        loop.set_postfix(loss=loss.item(), acc=correct / len(train_set))

    train_acc = correct / len(train_set)
    print(f"\n[Epoch {epoch+1}] Train Loss: {total_loss:.4f}, Train Acc: {train_acc:.4f}")

    model.eval()
    val_correct = 0
    with torch.no_grad():
        val_loop = tqdm(val_loader, desc=f"Epoch [{epoch+1}/{num_epochs}] Validation", ncols=100)
        for images, labels in val_loop:
            images = images.to(device)
            labels = labels.to(device).float().unsqueeze(1)

            outputs = model(images)
            preds = (torch.sigmoid(outputs) > 0.5).long()
            val_correct += (preds == labels.long()).sum().item()
            val_loop.set_postfix(val_acc=val_correct / len(val_set))

    val_acc = val_correct / len(val_set)
    print(f"[Epoch {epoch+1}] Val Acc: {val_acc:.4f}")


model.eval()
all_preds = []
all_labels = []
with torch.no_grad():
    test_loop = tqdm(test_loader, desc="Testing", ncols=100)
    for images, labels in test_loop:
        images = images.to(device)
        labels = labels.to(device).float().unsqueeze(1)

        outputs = model(images)
        probs = torch.sigmoid(outputs)
        preds = (probs > 0.5).long().cpu().squeeze(1)
        all_preds.extend(preds)
        all_labels.extend(labels.cpu().squeeze(1))

print("\nTest 报告:\n")
print(classification_report(all_labels, all_preds, target_names=test_set.classes))

torch.save(model.state_dict(), "best_resnet18_augmented.pth")
