import os
from PIL import Image
import torch
from torch.utils.data import Dataset, DataLoader
from transformers import SegformerForSemanticSegmentation, SegformerImageProcessor
import numpy as np
import torch.nn.functional as F
from tqdm import tqdm
from sklearn.model_selection import train_test_split

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class SegDataset(Dataset):
    def __init__(self, img_dir, mask_dir, processor, file_list, size=(512, 512)):
        self.img_dir = img_dir
        self.mask_dir = mask_dir
        self.processor = processor
        self.files = file_list
        self.size = size

    def __len__(self):
        return len(self.files)

    def __getitem__(self, idx):
        fname = self.files[idx]
        img_path = os.path.join(self.img_dir, fname)
        mask_path = os.path.join(self.mask_dir, fname)

        image = Image.open(img_path).convert("RGB").resize(self.size)
        mask = Image.open(mask_path).convert("L").resize(self.size)

        raw = np.array(mask)
        label = np.zeros_like(raw, dtype=np.uint8)
        label[raw == 128] = 1
        label[raw == 255] = 2
        label = torch.tensor(label).long()

        inputs = self.processor(images=image, return_tensors="pt")
        pixel_values = inputs.pixel_values.squeeze(0)

        return pixel_values, label, np.array(image), raw, fname


def save_val_visualization(epoch, images, preds, masks, img_names, save_dir="val_visualizations", max_samples=20):
    os.makedirs(f"{save_dir}/epoch_{epoch}", exist_ok=True)

    def mask_to_rgb(mask):
        color_map = {
            0: [0, 0, 0],        # 背景
            1: [255, 0, 0],      # 类别1 红色
            2: [0, 255, 0],      # 类别2 绿色
        }
        rgb = np.zeros((mask.shape[0], mask.shape[1], 3), dtype=np.uint8)
        for cls, color in color_map.items():
            rgb[mask == cls] = color
        return rgb

    for i in range(min(max_samples, len(images))):
        img = images[i]
        pred_mask = preds[i].cpu().numpy()
        true_mask = masks[i]

        mapped_true_mask = np.zeros_like(true_mask)
        mapped_true_mask[true_mask == 128] = 1
        mapped_true_mask[true_mask == 255] = 2

        pred_mask_resized = np.array(
            Image.fromarray(pred_mask.astype(np.uint8)).resize((img.shape[1], img.shape[0]), Image.NEAREST)
        )
        mapped_true_mask_resized = np.array(
            Image.fromarray(mapped_true_mask.astype(np.uint8)).resize((img.shape[1], img.shape[0]), Image.NEAREST)
        )

        pred_rgb = mask_to_rgb(pred_mask_resized)
        true_rgb = mask_to_rgb(mapped_true_mask_resized)

        overlay_pred = (img * 0.5 + pred_rgb * 0.5).astype(np.uint8)
        overlay_true = (img * 0.5 + true_rgb * 0.5).astype(np.uint8)

        concat_img = np.concatenate([img, overlay_pred, overlay_true], axis=1)

        save_path = os.path.join(save_dir, f"epoch_{epoch}", f"{img_names[i]}")
        if not save_path.endswith(".png"):
            save_path = os.path.splitext(save_path)[0] + ".png"
        Image.fromarray(concat_img).save(save_path)



def main():
    processor = SegformerImageProcessor(do_resize=False, do_normalize=True)
    model = SegformerForSemanticSegmentation.from_pretrained(
        "nvidia/segformer-b0-finetuned-ade-512-512",
        num_labels=3,
        ignore_mismatched_sizes=True,
    ).to(device)

    img_dir = r"E:\anaconda1\deep-learning\ttt\all_x_slices"
    mask_dir = r"E:\anaconda1\deep-learning\ttt\all_x_slices_mask"

    all_mask_files = sorted([f for f in os.listdir(mask_dir) if f.endswith((".png", ".jpg"))])
    all_mask_files = [f for f in all_mask_files if os.path.exists(os.path.join(img_dir, f))]

    train_files, val_files = train_test_split(all_mask_files, test_size=0.1, random_state=42)

    train_set = SegDataset(img_dir, mask_dir, processor, train_files)
    val_set = SegDataset(img_dir, mask_dir, processor, val_files)

    train_loader = DataLoader(train_set, batch_size=4, shuffle=True)
    val_loader = DataLoader(val_set, batch_size=4)

    optimizer = torch.optim.Adam(model.parameters(), lr=2e-4)

    for epoch in range(1, 6):
        model.train()
        total_loss = 0
        for imgs, masks, _, _, _ in tqdm(train_loader, desc=f"Epoch {epoch}"):
            imgs, masks = imgs.to(device), masks.to(device)
            outputs = model(pixel_values=imgs, labels=masks)
            loss = outputs.loss
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item()

        print(f"Epoch {epoch} Loss: {total_loss / len(train_loader):.4f}")

        model.eval()
        iou_total = 0
        val_images, val_preds, val_masks, val_img_names = [], [], [], []

        with torch.no_grad():
            for imgs, masks, orig_imgs, raw_masks, img_names in val_loader:
                imgs, masks = imgs.to(device), masks.to(device)
                logits = model(pixel_values=imgs).logits
                preds = logits.argmax(dim=1)

                masks_resized = F.interpolate(masks.unsqueeze(1).float(), size=preds.shape[1:], mode='nearest').squeeze(1).long()

                # IoU只评估类1、类2
                intersection = ((preds > 0) & (masks_resized > 0)).sum().float()
                union = ((preds > 0) | (masks_resized > 0)).sum().float()
                iou = (intersection + 1e-6) / (union + 1e-6)
                iou_total += iou.item()

                if len(val_images) < 20:
                    val_images.extend(orig_imgs.numpy())
                    val_preds.extend(preds.cpu())
                    val_masks.extend(raw_masks)  # 保留原始 mask（值为 0/128/255）
                    val_img_names.extend(img_names)

        print(f" Val IoU: {iou_total / len(val_loader):.4f}")
        save_val_visualization(epoch, val_images, val_preds, val_masks, val_img_names)

    torch.save(model.state_dict(), "segformer__tumor.pth")
    print(" val_visualizations/ 目录")


if __name__ == "__main__":
    main()
